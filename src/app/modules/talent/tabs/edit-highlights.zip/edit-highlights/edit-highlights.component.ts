import { Component } from '@angular/core';

@Component({
  selector: 'app-edit-highlights',
  templateUrl: './edit-highlights.component.html',
  styleUrl: './edit-highlights.component.scss'
})
export class EditHighlightsComponent {

}
