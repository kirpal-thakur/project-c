export const environment = {
    production: false,
    targetDomain: {
      domain: 'ch' 
    }
  } as const;
  