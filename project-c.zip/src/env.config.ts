// export const environment = {
//     enDomain: (window as any).__env.G_APP_EN_DOMAIN || '',
//     deDomain: (window as any).__env.NG_APP_DE_DOMAIN || ''
//   };
  