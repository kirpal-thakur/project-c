import { Component } from '@angular/core';

@Component({
  selector: 'app-user-purchase',
  templateUrl: './purchase.detail.component.html',
  styleUrl: './purchase.detail.component.scss'
})
export class PurchaseDetailComponent {
 
}
