import { Component } from '@angular/core';

@Component({
  selector: 'app-user-gallery',
  templateUrl: './gallery.detail.component.html',
  styleUrl: './gallery.detail.component.scss'
})
export class GalleryDetailComponent {
 
}
