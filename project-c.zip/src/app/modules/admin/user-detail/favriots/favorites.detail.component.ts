import { Component } from '@angular/core';

@Component({
  selector: 'app-user-favorites',
  templateUrl: './favorites.detail.component.html',
  styleUrl: './favorites.detail.component.scss'
})
export class FavoritesDetailComponent {
 
}
